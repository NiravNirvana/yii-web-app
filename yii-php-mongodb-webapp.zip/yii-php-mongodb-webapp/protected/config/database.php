<?php

// This is the database connection configuration.
return array(
	//'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/walltainc_athh_db.db',
	// uncomment the following lines to use a MySQL database
	
	//'connectionString' => 'mysql:host=localhost;dbname=gallery',
	//'emulatePrepare' => true,
	//'username' => 'root',
	//'password' => 'bharat@athh',
	//'charset' => 'utf8',
	
);